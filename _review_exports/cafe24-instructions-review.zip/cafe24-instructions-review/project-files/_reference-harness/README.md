# Reference Harness

원본 사이트·정식 보유 스킨을 **수집 → 불변 보관 → source↔original QA → 복사본에서만 수정**하는 실험 트랙.

> 비슷하게 **새로 만드는 reconstruction이 기본이 아닙니다.**

## 격리

| 경로 | 관계 |
|------|------|
| `_reference-harness/` | 실험 전용 |
| `templates/` · `wordpress/` · `cafe24/` | `07-final` PASS 후 승격 |

## 단계

| 단계 | 폴더 |
|------|------|
| 00-source | `00-source/` |
| 01-original | `01-original/` |
| 02-original-qa | `02-original-qa/` ★ |
| 03-analysis | `03-analysis/` |
| 04-working-copy | `04-working-copy/` |
| 05-working-qa | `05-working-qa/` |
| 06-normalized | `06-normalized/` (선택) |
| 07-final | `07-final/` |
| 08-platform-map | `08-platform-map/` |
| 09-platform-qa | `09-platform-qa/` |

Debug: `cases/{slug}/_dev/` (original 밖 · 납품 제외)

## SoT

| 문서 | |
|------|--|
| `shared/rules/workflow.md` | 파이프라인 |
| `original-immutable.md` · `original-revision.md` | 불변·rev |
| `original-qa.md` | source↔original QA |
| `analysis-artifacts.md` · `working-copy.md` | 분석·수정 |
| `page-index.md` · `page-inventory.md` | 비교 화면·스키마 |
| `cafe24-original.md` · `license.md` · `stage-gates.md` | 카페24·권리·게이트 |
| `legacy-migration.md` | 구 폴더·case 재분류 |
| `.cursor/rules/83-reference-harness.mdc` | 에이전트 |

## Case 구조 (신규)

```
cases/{slug}/
├── manifest.json
├── 00-source/
├── 01-original/
├── 02-original-qa/
├── 03-analysis/
├── 04-working-copy/
├── 05-working-qa/
├── 06-normalized/
├── 07-final/
├── 08-platform-map/
├── 09-platform-qa/
└── _dev/
```

## 기존 case

즉시 rename 없음. 상태표: `shared/rules/legacy-migration.md`  
sample03: browser-captured original 있음 · **originalQa 미실시** · working-copy 금지

## 시작

```bash
# URL
node scripts/mirror-original.js {slug} {url}
node scripts/preview-original.js {slug}
# → 02-original-qa 후 사용자 확인

# 정식 ZIP
# 00-source/license.md 작성 → 01-original에 해제(수정 금지) → checksum → 02-original-qa
```

## 뷰포트

1920 / 390
